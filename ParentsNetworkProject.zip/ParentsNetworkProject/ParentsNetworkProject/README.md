for parents project

Welcome to **The Parents Network** project

Parent's Network:  is a project aimed at supporting parents in effectively managing their time,
balancing various responsibilities, and fostering a healthy work-life-parenting dynamic. 
The project provides practical strategies, tools, and resources to 
empower parents in optimizing their time management skills.

This project was created with:

-python

-Django

-HTML

-CSS

Usage:

-Register or login to your home page

-add notice to your work life

-you have oppiction to cantact with admin web 
to change in your schedule study/health. 

-change privates in seeting account

Support:

If you have any questions or need help 
with the installation and usage of the ParentNetwork  project,
receive valuable time management tips,

project setup:

Follow these steps to set up The Parents Network project on your computer:
1. make sure you have the python 3.12 in your computer 
2. pip install  django 5.0.3
3. make sure python is in path-
4. that’s it you are all set up to run.

'start server':  python manage.py runserver'

Apply migrations - `python manage.py migrate


 
